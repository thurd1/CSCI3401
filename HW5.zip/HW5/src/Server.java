import java.io.*;
import java.net.*;
import java.util.Random;

/**
 * 
 * @author Hurd, Trenton
 * @Assignment 5
 * @date 04/15/2024
 * 
 */

public class Server {

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Server waiting for client...");

            Socket clientSocket = serverSocket.accept(); //Accept client connection
            System.out.println("Client connected.");

            handleClientRequest(clientSocket);//Handle client request

            clientSocket.close(); //Close client socket
            System.out.println("Client socket closed.");

            serverSocket.close(); //Close server socket
            System.out.println("Server socket closed.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClientRequest(Socket clientSocket) throws IOException {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
            String filename = null;

            String request = in.readLine(); //Wait for "aloha" from client
            System.out.println("Received request from client: " + request);
            if (request.equals("aloha")) {
                System.out.println("Request equals 'aloha'.");

                out.println("Welcome to the server!"); //Send welcome message to client
                System.out.println("Welcome message sent to client.");

                Random random = new Random(); //Receive file from client
                int randomNumber = random.nextInt(1000);
                filename = "Server" + randomNumber + ".txt";
                System.out.println("Generated filename: " + filename);
                FileOutputStream fos = new FileOutputStream(filename);
                InputStream is = clientSocket.getInputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;
                int totalBytesRead = 0; 
                while ((bytesRead = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                }
                fos.close();
                System.out.println("File received and saved as '" + filename + "'.");
                System.out.println("Total bytes read: " + totalBytesRead);

                File uploadedFile = new File(filename);//Send confirmation message to client
                long fileSize = uploadedFile.length();
                String confirmationMessage = "Your file named " + filename + " with the size " + fileSize + " bytes has been uploaded correctly.";
                out.println(confirmationMessage);
                System.out.println("Confirmation message sent to client: " + confirmationMessage);
            } else {
                System.out.println("Client did not send 'aloha'. Closing connection.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
