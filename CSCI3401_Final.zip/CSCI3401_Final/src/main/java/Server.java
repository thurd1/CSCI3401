// Server.java
import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
    private static final int PORT = 80;
    private static final String FILES_DIRECTORY = "server_files/";

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server started, waiting for connections...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                ClientHandler clientHandler = new ClientHandler(clientSocket);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            ) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    String[] tokens = inputLine.split(" ");
                    String command = tokens[0].toLowerCase();
                    switch (command) {
                        case "upload":
                            handleUpload(tokens[1], out);
                            break;
                        case "download":
                            handleDownload(tokens[1], out);
                            break;
                        case "display":
                            displayFiles(out);
                            break;
                        case "teardown":
                            clientSocket.close();
                            return;
                        case "close":
                            System.exit(0);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private void handleUpload(String filename, PrintWriter out) throws IOException {
            // Simulate file upload
            // Here, you would receive the file content from the client and save it to server's file system
            // For simplicity, let's just acknowledge the upload
            out.println("Upload successful for file: " + filename);
        }

        private void handleDownload(String filename, PrintWriter out) throws IOException {
            // Simulate file download
            // Here, you would read the file content from the server's file system and send it to the client
            // For simplicity, let's just acknowledge the download
            out.println("Download successful for file: " + filename);
        }

        private void displayFiles(PrintWriter out) {
            File folder = new File(FILES_DIRECTORY);
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    out.println(file.getName());
                }
            }
        }
    }
}
