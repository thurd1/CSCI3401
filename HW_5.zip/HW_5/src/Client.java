import java.io.*;
import java.net.*;


/**
 * 
 * @author Hurd, Trenton
 * @Assignment 5
 * @date 04/15/2024
 * 
 */

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out.println("aloha"); //Send "aloha" to the server
            System.out.println("Sent 'aloha' to server.");

            String response = in.readLine(); //Receive welcome message from server
            System.out.println("Server: " + response);

            if (response.equals("Welcome to the server!")) { //Check if the welcome message is received successfully before proceeding
             
                File file = new File("paper.txt");//Upload file to server
                FileInputStream fis = new FileInputStream(file);
                OutputStream os = socket.getOutputStream();
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
                os.flush();
                System.out.println("File 'paper.txt' sent to server.");

                String confirmation = in.readLine(); //Receive confirmation message from server
                System.out.println("Server: " + confirmation);

                if (confirmation.startsWith("Your file named")) { //Check if the confirmation message is received successfully before closing the socket
                   
                    fis.close(); //Close streams and socket
                    os.close();
                    in.close();
                    out.close();
                    socket.close();
                    System.out.println("Connection closed.");
                }
            } else {
                System.out.println("Failed to receive welcome message from server.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
